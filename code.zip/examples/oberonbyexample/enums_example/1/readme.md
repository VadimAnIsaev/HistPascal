

Example aimed to show how to survive without enumerations in Oberon.

This example is contributed by @pdewacht.
