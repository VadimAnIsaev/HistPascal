

Example aimed to show how to survive without enumerations in Oberon.

This way is even cooler than enumerations. (:

