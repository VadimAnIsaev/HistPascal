/*------------------------------------------------------
 Программа для решения системы линейных уравнений (СЛАУ)
 типа Ax = B, на языке программирования Си,
 компилятор GNU C (http://gcc.gnu.org/).
 Метод Гаусса.
 
 Компиляция:
    - без оптимизации:
    gcc gauss.c -o gauss
    
    - с опртимизацией по скорости выполнения:
    gcc gauss.c -o gauss -Ofast
------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Выделение памяти под расширенную матрицу
   N * N+1
   и заполнение её случайными числами.
   Входные параметры:
   	n - размер матрицы
*/
double ** inputs (int n)
{
  int i, j;

  // Расширенная матрица
  double ** a=(double **)malloc(sizeof(double *)*n);
  
  srand(time(NULL));
  printf("Заполнение матрицы A...\n");
  
  for(i=0;i<n;i++)
  {
    a[i]=(double *)malloc(sizeof(double)*(n+2));
    for(j=0;j<n;j++)
      a[i][j] = rand();
  };
  printf("Заполнение вектора B...\n");
  for(i=0;i<n;i++)
  {
    a[i][n] = rand()+1;
  }

  return a;
}


/*------------------------------------------------------
 Функция вычисления системы линейных уравнений СЛАУ
 типа Ax=B методом Гаусса.
 Входные параметры:
    a - расширеная матрица коэффициентов, размером N x N+1
	в которой последний столбец - свободные члены B;
    n - количество уравнений.
 Возвращаемое значение:
    вектор решения СЛАУ размером n.
 -----------------------------------------------------*/
double * GaussElim(double **a, int n)
{
  int i, k, j;
  // Вектор решения СЛАУ
  double * x=(double *) malloc(sizeof(double)*n);
  double m;

  // Прямая замена
  for(i=0;i<n;i++)
  {
    for(k=i+1;k<n;k++)
    {
      m=-a[k][i]/a[i][i];
      for(j=i;j<n+1;j++)
      {
        a[k][j]=a[k][j]+m*a[i][j];
      }
    }
  }

  // Обратная замена
  for(i=n-1;i>=0;i--)
  {
    x[i]=a[i][n]/a[i][i];
    for(k=i-1;k>=0;k--)
    {
      a[k][n]-=a[k][i]*x[i];
    }
  }
  return x;
}


int main()
{
  double * x;
  double ** a;
  int i,j;
  int n = 3000;
  time_t start_time, end_time;
  float tm;
  
  printf("Размер матрицы %d\n", n);
  a = inputs(n);
  printf("Начинаем вычислять...\n");
  start_time = clock();
  x = GaussElim(a, n);
  end_time = clock();
  
  puts("Мы закончили...");
  tm = ((float)end_time-start_time) / CLOCKS_PER_SEC;
  printf("Время работы: ");
  printf("%8.3f секунд\n\n", tm);
  
  return 0;
}

